<style>
  .yazi{
    font-size: 20px !important;
  }
</style>
  

          <a onclick="window.location.href = '/adresler.php'" href="javascript:;"class="btn yazi">Adreslerim</a>
          <br>
          <a onclick="window.location.href = '/accountdetails.php'" href="javascript:;"class="btn yazi">Hesap Detayları</a>
          <br>
          <a onclick="window.location.href = '/password.php'" href="javascript:;" class="btn yazi">Şifre Güncelleme</a>
          <br>
          <a onclick="window.location.href = '/veterinaryOfficer.php'" href="javascript:;" class="btn yazi">Veteriner Başvurusu</a>
          <br>
          <a onclick="window.location.href = '/dijitalPasaport.php'" href="javascript:;" class="btn yazi">Pasaportlarım</a>
          <br>
          <a onclick="window.location.href = '/logout.php'" href="javascript:;" class="btn btn-primary mt-2 yazi">
            <i class="fa fa-sign-out" aria-hidden="true"></i> &nbsp; Çıkış Yap </a>

        
         